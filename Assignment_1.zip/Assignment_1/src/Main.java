import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner s=new Scanner(System.in);

        System.out.print("Enter full name: ");
        String name=s.nextLine();

        System.out.println(name);
        System.out.println("It is a versatile, platform-independent language widely used in web, mobile, and enterprise applications.");
        System.out.println("My career goal is to become a skilled and innovative software engineer");
    }
}